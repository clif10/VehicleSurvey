package com.myorg.data;

import java.util.Calendar;
import java.util.Date;

import com.myorg.data.Enums.Day;

public class Constants {
	

}