package com.myorg.data;

public class Enums {

	public enum Day {
	    MONDAY, TUESDAY, WEDNESDAY,
	    THURSDAY, FRIDAY; 
	    
	    int value(){
	        switch(this) {
	         case MONDAY: return 1;
	         case TUESDAY: return 2;
	         case WEDNESDAY: return 3;
	         case THURSDAY: return 4;
	         case FRIDAY: return 5;
	         
	         default: return 0;
	       }
	    }

	}

public enum TimeInDay {
    MORNING,
    EVENING
}

}
