package com.myorg.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.myorg.data.Enums.Day;

public class Util {

	
	
	public static Day getDayOfRun() {
		// TODO Auto-generated method stub
		return null;
	}

	public static Long getTimeInMiilisec(String stringInMillisec) {
		
		//Assuming that the first character will always be a string
		String timeInMillisecStr = stringInMillisec.substring(1);
		
		Long returnValue = Long.valueOf(timeInMillisecStr);
			
		return returnValue;
		
		
	}
	
	public static Long decideTimeOfDay(Long timeInMillisec) 
	{
		
	
		Date date = new Date(timeInMillisec);
		
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy HH:mm");

		System.out.println(sdf.format(date));  
		 

		Long returnValue = null;
		
		return returnValue;
		
		
	}

	public Calendar getReferenceDate()
	{
		Calendar referenceCalendar = Calendar.getInstance();
		
		referenceCalendar.set(2012,01,13,0,0);
		
		return referenceCalendar;
	}
	
}
