package com.myorg.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.myorg.data.Enums.TimeInDay;
import com.myorg.data.VehicleData;
import com.myorg.utils.Util;

public class Surveyor {

	
	/*
	 * Map to store data of the NorthBound Vehicles
	 * 
	 */	
	static Map<Integer, VehicleData> northBoundMap = null;
	
	/*
	 * Map to store data of the SouthBound Vehicles
	 * 
	 */	
	static Map<Integer, VehicleData> southBoundMap = null;
	
	static List<String> carTimings = null;
	

	static int northBoundKey = 0;
	
	static int southBoundKey = 0;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		northBoundMap = new HashMap<Integer, VehicleData>();
		southBoundMap = new HashMap<Integer, VehicleData>();
		
		carTimings = new ArrayList<String>();
		
		carTimings.add("A268981");
		carTimings.add("A269123");
		carTimings.add("A604957");
		carTimings.add("B604960");
		carTimings.add("A605128");
		carTimings.add("B605132");
		carTimings.add("A1089807");
		carTimings.add("B1089810");
		carTimings.add("A1089948");
		carTimings.add("B1089951");
		
		readVehicleTimings();
		
	}

	private static void readVehicleTimings() {
		//TODO: replace the for loop by reading from a file
		String firstReading = null;
		String secondReading = null;
		for (int firstIndex=0; firstIndex < 10 ; firstIndex++)
		{
			firstReading = carTimings.get(firstIndex);
			secondReading = carTimings.get(++firstIndex);
			
			if (secondReading.startsWith("B"))
			{
				invokeSouthBoundHandler(firstIndex);
				firstIndex+=2;
			}
			else
			{
				invokeNorthBoundHandler(firstIndex);
			}
		
		}
		
		System.out.println("Cars in the morning are " + getCountOfcarsInMorning());
		
	}

	private static void invokeNorthBoundHandler(int firstIndex) {
		VehicleData vehicleData = new VehicleData();
		
		Long timeInMillisecFrontWheel = Util.getTimeInMiilisec(carTimings.get(firstIndex - 1));
		
		Long timeInMillisecRearWheel = Util.getTimeInMiilisec(carTimings.get(firstIndex));
		
		Long differenceInMilliSec = timeInMillisecRearWheel - timeInMillisecFrontWheel;
	
		vehicleData.setDifferenceInMillisec(differenceInMilliSec.intValue());
		
		northBoundMap.put(++northBoundKey,vehicleData);
		
	}

	/* The method should be able to check the container and find the difference between the 
	 * predessesor timing and the successor timing
	 * Hence A-B are the front wheels and the succeeding A-B pair are the rear wheels
	 * Hence the A(front wheel) and A(rear wheel) will give the difference
	 * 
	 * TODO: Do we also need to take care of two cars moving side by side
	 * 
	 */
	private static void invokeSouthBoundHandler(int firstIndex) {
		VehicleData vehicleData = new VehicleData();
		
		Long timeInMillisecFrontWheel = Util.getTimeInMiilisec(carTimings.get(firstIndex - 1));
		
		Long timeInMillisecRearWheel = Util.getTimeInMiilisec(carTimings.get(firstIndex + 1));
		
		Long differenceInMilliSec = timeInMillisecRearWheel - timeInMillisecFrontWheel;
	
		vehicleData.setDifferenceInMillisec(differenceInMilliSec.intValue());
		
		
		
		vehicleData.setTimeInDay(timeInDay);
		
		vehicleData.setTimeOfRun(timeOfRun);
		
		vehicleData.setDayOfRun(Util.getDayOfRun(differenceInMilliSec));
		
		southBoundMap.put(++southBoundKey,vehicleData);
		 
	
	}

	public int getCountForNothBound() {
		
		return northBoundMap.size();
	}

	public static int getCountOfcarsInMorning() {
		
		int noInSouthbound = getCountOfcarsInMorning(northBoundMap);
		int noInNorthbound = getCountOfcarsInMorning(southBoundMap);
		
		int totalInMorning = noInSouthbound + noInNorthbound;
		
		return totalInMorning;
		
	}

	private static int getCountOfcarsInMorning(Map<Integer, VehicleData> directionMap) {
		
		int morningCounter = 0;
		
		Iterator<Map.Entry<Integer, VehicleData>> entries = directionMap.entrySet().iterator();
		while (entries.hasNext()) 
		{ 
			Map.Entry<Integer, VehicleData> entry = entries.next(); 
			System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
			if(TimeInDay.MORNING == entry.getValue().getTimeInDay())
				morningCounter+=1;
			
		}
		
		
		return 0;
	}

}
