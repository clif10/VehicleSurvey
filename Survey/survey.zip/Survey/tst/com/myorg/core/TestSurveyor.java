package com.myorg.core;

import junit.framework.Assert;

import org.junit.Test;

public class TestSurveyor {
	
	 
	@Test
	public void testCountForNorthBound() {
 
		Surveyor surveyor = new Surveyor();
		
		Assert.assertEquals(surveyor.getCountForNothBound() , 2);
 
	}

}
